package glacialExpedition.models.states;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class StateImpl implements State{
    private String name;
    private List<String> exhibits;

    public StateImpl(String name) {
        this.name = name;
        this.exhibits = new ArrayList<>();
    }

    @Override
    public Collection<String> getExhibits() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }
}
